# speech-translation
•	Speech to text is deployed on flask and provides the text where speech as input.
•	It takes wav format of speech and converts to text.
•	It uses speech_recogntion from converting speech to text.
